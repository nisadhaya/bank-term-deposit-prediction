
import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os

# ==============================
# PAGE CONFIGURATION
# ==============================
st.set_page_config(
    page_title="Bank Term Deposit Prediction",
    page_icon="🏦",
    layout="wide"
)

# ==============================
# LOAD SAVED MODEL
# ==============================
MODEL_PATH = "/content/bank_model/random_forest_model.pkl"
PREPROCESSOR_PATH = "/content/bank_model/preprocessor.pkl"
THRESHOLD_PATH = "/content/bank_model/threshold.pkl"

model = joblib.load(MODEL_PATH)
preprocessor = joblib.load(PREPROCESSOR_PATH)
threshold = joblib.load(THRESHOLD_PATH)

# ==============================
# HEADER
# ==============================
st.title("🏦 Bank Term Deposit Prediction System")
st.markdown(
    "### Predict whether a customer is likely to subscribe to a term deposit"
)

st.divider()

# ==============================
# SIDEBAR
# ==============================
st.sidebar.header("📌 Project Information")

st.sidebar.info(
    """
    **Machine Learning Model**

    Tuned Random Forest

    **Explainability**

    SHAP + LIME

    **Monitoring**

    KS-based drift check
    """
)

# ==============================
# CUSTOMER INPUT
# ==============================
st.header("👤 Customer Information")

col1, col2, col3 = st.columns(3)

with col1:
    age = st.number_input(
        "Age",
        min_value=18,
        max_value=100,
        value=35
    )

    job = st.selectbox(
        "Job",
        [
            "admin.",
            "blue-collar",
            "entrepreneur",
            "housemaid",
            "management",
            "retired",
            "self-employed",
            "services",
            "student",
            "technician",
            "unemployed",
            "unknown"
        ]
    )

    marital = st.selectbox(
        "Marital Status",
        ["married", "single", "divorced", "unknown"]
    )

    education = st.selectbox(
        "Education",
        [
            "basic.4y",
            "basic.6y",
            "basic.9y",
            "high.school",
            "illiterate",
            "professional.course",
            "university.degree",
            "unknown"
        ]
    )

with col2:
    default = st.selectbox(
        "Credit Default",
        ["no", "yes", "unknown"]
    )

    housing = st.selectbox(
        "Housing Loan",
        ["yes", "no", "unknown"]
    )

    loan = st.selectbox(
        "Personal Loan",
        ["yes", "no", "unknown"]
    )

    contact = st.selectbox(
        "Contact Type",
        ["cellular", "telephone"]
    )

with col3:
    month = st.selectbox(
        "Contact Month",
        [
            "mar", "apr", "may", "jun",
            "jul", "aug", "sep", "oct",
            "nov", "dec"
        ]
    )

    day_of_week = st.selectbox(
        "Day of Week",
        ["mon", "tue", "wed", "thu", "fri"]
    )

    campaign = st.number_input(
        "Campaign Contacts",
        min_value=1,
        max_value=50,
        value=2
    )

    previous = st.number_input(
        "Previous Contacts",
        min_value=0,
        max_value=20,
        value=0
    )

st.divider()

# ==============================
# ADDITIONAL INPUTS
# ==============================
st.header("📊 Economic & Previous Campaign Information")

col4, col5, col6 = st.columns(3)

with col4:
    pdays = st.number_input(
        "Days Since Previous Contact",
        min_value=0,
        max_value=999,
        value=999
    )

    poutcome = st.selectbox(
        "Previous Campaign Outcome",
        ["nonexistent", "failure", "success"]
    )

with col5:
    emp_var_rate = st.number_input(
        "Employment Variation Rate",
        value=1.1
    )

    cons_price_idx = st.number_input(
        "Consumer Price Index",
        value=93.994
    )

with col6:
    cons_conf_idx = st.number_input(
        "Consumer Confidence Index",
        value=-36.4
    )

    euribor3m = st.number_input(
        "Euribor 3 Month Rate",
        value=4.857
    )

    nr_employed = st.number_input(
        "Number of Employees",
        value=5191.0
    )

# ==============================
# PREDICTION BUTTON
# ==============================
st.divider()

predict_button = st.button(
    "🔮 PREDICT TERM DEPOSIT",
    use_container_width=True
)

if predict_button:

    # ------------------------------
    # FEATURE ENGINEERING
    # ------------------------------

    was_previously_contacted = int(pdays != 999)

    if age <= 25:
        age_group = "Young"
    elif age <= 40:
        age_group = "Adult"
    elif age <= 60:
        age_group = "Middle-aged"
    else:
        age_group = "Senior"

    if pdays <= 7:
        pdays_group = "Within_1_week"
    elif pdays <= 30:
        pdays_group = "Within_1_month"
    elif pdays <= 90:
        pdays_group = "Within_3_months"
    elif pdays <= 365:
        pdays_group = "Within_1_year"
    else:
        pdays_group = "Not_recently_contacted"

    if previous == 0:
        previous_contact_level = "None"
    elif previous == 1:
        previous_contact_level = "One"
    else:
        previous_contact_level = "Multiple"

    high_campaign_effort = int(campaign >= 4)
    prior_success = int(poutcome == "success")

    n_existing_loans = (
        int(housing == "yes") +
        int(loan == "yes")
    )

    macro_climate_index = np.mean([
        emp_var_rate,
        cons_price_idx,
        cons_conf_idx,
        euribor3m,
        nr_employed
    ])

    # ------------------------------
    # CREATE CUSTOMER DATA
    # ------------------------------

    customer = pd.DataFrame({
        "age": [age],
        "job": [job],
        "marital": [marital],
        "education": [education],
        "default": [default],
        "housing": [housing],
        "loan": [loan],
        "contact": [contact],
        "month": [month],
        "day_of_week": [day_of_week],
        "campaign": [campaign],
        "pdays": [pdays],
        "previous": [previous],
        "poutcome": [poutcome],
        "emp.var.rate": [emp_var_rate],
        "cons.price.idx": [cons_price_idx],
        "cons.conf.idx": [cons_conf_idx],
        "euribor3m": [euribor3m],
        "nr.employed": [nr_employed],

        # Engineered features
        "was_previously_contacted": [was_previously_contacted],
        "age_group": [age_group],
        "pdays_group": [pdays_group],
        "previous_contact_level": [previous_contact_level],
        "high_campaign_effort": [high_campaign_effort],
        "prior_success": [prior_success],
        "n_existing_loans": [n_existing_loans],
        "macro_climate_index": [macro_climate_index]
    })

    # ------------------------------
    # PREPROCESS
    # ------------------------------

    customer_processed = preprocessor.transform(customer)

    # ------------------------------
    # PREDICTION
    # ------------------------------

    probability = model.predict_proba(customer_processed)[0, 1]

    if probability >= threshold:
        prediction = "YES"
    else:
        prediction = "NO"

    # ==============================
    # DISPLAY RESULT
    # ==============================

    st.divider()
    st.header("📊 Prediction Result")

    result_col1, result_col2, result_col3 = st.columns(3)

    with result_col1:
        st.metric(
            "Subscription Prediction",
            prediction
        )

    with result_col2:
        st.metric(
            "Probability",
            f"{probability * 100:.2f}%"
        )

    with result_col3:
        st.metric(
            "Decision Threshold",
            f"{threshold * 100:.2f}%"
        )

    if prediction == "YES":
        st.success(
            "✅ Customer is predicted to subscribe to the term deposit."
        )
    else:
        st.warning(
            "❌ Customer is predicted not to subscribe to the term deposit."
        )

    # Probability bar
    st.subheader("📈 Subscription Probability")

    st.progress(float(probability))

    # Customer details
    with st.expander("👤 View Customer Input Data"):
        st.dataframe(customer)

    # Responsible AI
    with st.expander("🛡️ Responsible AI"):
        st.write("**Fairness:** Check performance across customer groups.")
        st.write("**Transparency:** SHAP and LIME explain predictions.")
        st.write("**Privacy:** Protect customer information.")
        st.write("**Human Oversight:** Prediction supports human decisions.")
        st.write("**Limitation:** Prediction is not a guarantee.")
